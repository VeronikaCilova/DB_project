
INSERT INTO course (course_name, start_date, end_date, capacity, description) VALUES
('Programování v Pythonu', '2024-04-01', '2024-06-30', 30, 'Kurz zaměřený na základy programování v Pythonu.'),
('Web Development', '2024-05-01', '2024-07-31', 25, 'Kurz zaměřený na vývoj webových aplikací.'),
('Databázové systémy', '2024-06-01', '2024-08-31', 20, 'Kurz zaměřený na práci s relačními databázemi.'),
('Grafický design', '2024-07-01', '2024-09-30', 15, 'Kurz zaměřený na základy grafického designu.'),
('Mobilní aplikace', '2024-08-01', '2024-10-31', 20, 'Kurz zaměřený na vývoj mobilních aplikací.'),
('UI/UX design', '2024-09-01', '2024-11-30', 15, 'Kurz zaměřený na design uživatelského rozhraní a uživatelské zkušenosti.'),
('Front-end vývoj', '2024-10-01', '2024-12-31', 20, 'Kurz zaměřený na vývoj front-endu webových aplikací.'),
('Back-end vývoj', '2024-11-01', '2025-01-31', 20, 'Kurz zaměřený na vývoj back-endu webových aplikací.');

INSERT INTO student (first_name, last_name, email, phone_number, address) VALUES
('Jan', 'Novák', 'jan.novak@email.com', '123456789', 'Praha, Česká republika'),
('Eva', 'Svobodová', 'eva.svobodova@email.com', '987654321', 'Brno, Česká republika'),
('Petr', 'Dvořák', 'petr.dvorak@email.com', '456123789', 'Ostrava, Česká republika'),
('Lucie', 'Horáková', 'lucie.horakova@email.com', '789456123', 'Plzeň, Česká republika'),
('Tomáš', 'Pospíšil', 'tomas.pospisil@email.com', '321654987', 'Olomouc, Česká republika'),
('Karolína', 'Nováková', 'karolina.novakova@email.com', '159753468', 'Liberec, Česká republika'),
('Jiří', 'Kovářík', 'jiri.kovarik@email.com', '357159456', 'Ústí nad Labem, Česká republika'),
('Petra', 'Sedláčková', 'petra.sedlackova@email.com', '951357468', 'Hradec Králové, Česká republika'),
('Lukáš', 'Marek', 'lukas.marek@email.com', '468135792', 'České Budějovice, Česká republika'),
('Anna', 'Holá', 'anna.hola@email.com', '123789456', 'Zlín, Česká republika');

INSERT INTO trainer (first_name, last_name, email, phone_number) VALUES
('Martin', 'Kovář', 'martin.kovar@email.com', '111222333'),
('Veronika', 'Marešová', 'veronika.maresova@email.com', '444555666'),
('Jiří', 'Němec', 'jiri.nemec@email.com', '777888999'),
('Kateřina', 'Novotná', 'katerina.novotna@email.com', '101112131'),
('Lukáš', 'Ševčík', 'lukas.sevcik@email.com', '141516171');

INSERT INTO student_course_signup (student_id, course_id, trainer_id, signup_date) VALUES
(1, 1, 1, '2024-03-20'),
(2, 1, 1, '2024-03-21'),
(3, 2, 2, '2024-03-22'),
(4, 3, 2, '2024-03-23'),
(5, 4, 2, '2024-03-24'),
(6, 5, 3, '2024-03-25'),
(7, 6, 3, '2024-03-26'),
(8, 7, 4, '2024-03-27'),
(9, 8, 5, '2024-03-28'),
(10, 8, 5, '2024-03-29');