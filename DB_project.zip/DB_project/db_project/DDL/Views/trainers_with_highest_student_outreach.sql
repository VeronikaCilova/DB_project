-- tento view vraci TOP 3 trenery s nejvetsim dosahem studentu,
-- jinymi slovy trenery, kteri vyucuji kurzy s nejvetsim poctem zapsanych studentu
CREATE VIEW trainers_with_highest_student_outreach AS
SELECT 
    t.trainer_id,
    t.first_name AS trainer_first_name,
    t.last_name AS trainer_last_name,
    t.email AS trainer_email,
    t.phone_number AS trainer_phone_number,
    COUNT(DISTINCT scs.student_id) AS student_outreach
FROM 
    trainer t
JOIN 
    student_course_signup scs ON t.trainer_id = scs.trainer_id
JOIN
    course c ON scs.course_id = c.course_id
GROUP BY 
    t.trainer_id, t.first_name, t.last_name, t.email, t.phone_number
ORDER BY 
    student_outreach DESC
LIMIT 3;


SELECT * FROM trainers_with_highest_student_outreach;
