-- tento view vraci trenery kteri vyucuji alespon 2 kurzy
CREATE VIEW trainers_teaching_atleast_2_courses AS
SELECT 
    t.trainer_id,
    t.first_name AS trainer_first_name,
    t.last_name AS trainer_last_name,
    t.email AS trainer_email,
    t.phone_number AS trainer_phone_number
FROM 
    trainer t
JOIN 
    student_course_signup scs ON t.trainer_id = scs.trainer_id
GROUP BY 
    t.trainer_id
HAVING 
    COUNT(DISTINCT scs.course_id) >= 2;
SELECT * FROM trainers_teaching_atleast_2_courses;

    
