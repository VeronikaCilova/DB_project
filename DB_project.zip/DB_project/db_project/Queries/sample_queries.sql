-- zde ulozte par SELECT dotazu vyuzivajicich JOIN, prip. UNION nad tabulkami v projektu
SELECT * FROM courses_with_most_signed_up_students;
SELECT * from report_all_data;
SELECT * FROM trainers_teaching_atleast_2_courses;
SELECT * FROM trainers_with_highest_student_outreach;


SELECT t.trainer_id, t.first_name, t.last_name, COUNT(c.course_id) AS number_of_courses
FROM trainer t
JOIN student_course_signup scs ON t.trainer_id = scs.trainer_id
JOIN course c ON scs.course_id = c.course_id
GROUP BY t.trainer_id, t.first_name, t.last_name;

SELECT student_id, first_name, last_name, email, phone_number, address
FROM student
UNION
SELECT trainer_id, first_name, last_name, email, phone_number, NULL AS address
FROM trainer;
